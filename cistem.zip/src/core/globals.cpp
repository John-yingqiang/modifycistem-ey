#include "core_headers.h"

RandomNumberGenerator global_random_number_generator(-1);

#include <wx/arrimpl.cpp> // this is a magic incantation which must be done!
WX_DEFINE_OBJARRAY(wxArrayFloat);
WX_DEFINE_OBJARRAY(wxArrayBool);

