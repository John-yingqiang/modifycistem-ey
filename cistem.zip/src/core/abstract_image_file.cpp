#include "core_headers.h"
AbstractImageFile::AbstractImageFile()
{

}

AbstractImageFile::AbstractImageFile(std::string wanted_filename, bool overwrite)
{

}

AbstractImageFile::~AbstractImageFile()
{

}
